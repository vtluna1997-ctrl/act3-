# Filtros digitales para una señal de caudal

Ejemplo en Python que simula una lectura de caudal con tres componentes identificables: variación lenta del proceso (0.18 Hz), pulsación de bomba (1.20 Hz), interferencia eléctrica (18 Hz) y ruido blanco. Compara filtros IIR Butterworth y Chebyshev tipo II con un filtro FIR de ventana Kaiser.

## Requisitos

Python 3.10 o posterior y las bibliotecas incluidas en `requirements.txt`.

## Ejecución

```bash
python -m pip install -r requirements.txt
python analisis_caudal.py
```

El programa genera las gráficas en `figuras/` y las mediciones en `resultados/`. La semilla aleatoria está fija para facilitar la repetición.

## Archivos

- `analisis_caudal.py`: construcción de la señal, filtros, medición de amplitudes y visualización.
- `figuras/`: traza de entrada, respuestas en frecuencia, señales filtradas y espectros.
- `resultados/`: tabla CSV de ganancias y resumen JSON.

Los datos son sintéticos y se usan únicamente con fines formativos; no representan una medición real de caudal.
