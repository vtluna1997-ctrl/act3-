"""Filtra una lectura sintética de caudal y compara las componentes recuperadas.

El ejemplo es reproducible y didáctico: no usa datos de un sistema real.
Ejecutar `python analisis_caudal.py` genera gráficas, CSV y resumen JSON.
"""
from pathlib import Path
import csv
import json

import matplotlib.pyplot as plt
import numpy as np
from scipy import signal

ROOT = Path(__file__).resolve().parent
FIG = ROOT / "figuras"
OUT = ROOT / "resultados"
FIG.mkdir(exist_ok=True)
OUT.mkdir(exist_ok=True)

FS = 200.0
DURATION = 30.0
SEED = 6152026
rng = np.random.default_rng(SEED)
t = np.arange(0, DURATION, 1 / FS)

# Tres componentes: variación lenta del proceso, pulsación de bomba e interferencia.
FREQS = {"Deriva de proceso": 0.18, "Pulsación de bomba": 1.20, "Interferencia eléctrica": 18.0}
AMPS = {"Deriva de proceso": 0.30, "Pulsación de bomba": 0.22, "Interferencia eléctrica": 0.10}
phases = {"Deriva de proceso": 0.3, "Pulsación de bomba": -0.4, "Interferencia eléctrica": 0.8}
components = {
    name: amp * np.sin(2 * np.pi * FREQS[name] * t + phases[name])
    for name, amp in AMPS.items()
}
clean = sum(components.values())
noise = rng.normal(0, 0.04, size=t.size)
measurement = clean + noise

# Filtros de diferentes familias: Butterworth IIR, Chebyshev II IIR y FIR Kaiser.
sos_lp = signal.butter(4, 4.0, btype="lowpass", fs=FS, output="sos")
sos_hp = signal.cheby2(4, 35, 0.60, btype="highpass", fs=FS, output="sos")
taps_bp = signal.firwin(601, [0.60, 3.0], pass_zero=False, fs=FS, window=("kaiser", 7.0))
filters = {
    "Pasa bajos Butterworth": ("IIR Butterworth, orden 4", "sos", sos_lp),
    "Pasa altos Chebyshev II": ("IIR Chebyshev II, orden 4", "sos", sos_hp),
    "Pasa bandas FIR Kaiser": ("FIR Kaiser, 601 coeficientes", "ba", (taps_bp, np.array([1.0]))),
}
outputs = {
    "Pasa bajos Butterworth": signal.sosfiltfilt(sos_lp, measurement),
    "Pasa altos Chebyshev II": signal.sosfiltfilt(sos_hp, measurement),
    "Pasa bandas FIR Kaiser": signal.filtfilt(taps_bp, [1.0], measurement),
}

# Ajuste seno-coseno en la parte central para medir cada componente conocida.
valid = (t >= 2.0) & (t <= DURATION - 2.0)
def fit_amplitude(y, freq):
    tv = t[valid]
    design = np.column_stack([np.sin(2*np.pi*freq*tv), np.cos(2*np.pi*freq*tv), np.ones(tv.size)])
    coef, *_ = np.linalg.lstsq(design, y[valid], rcond=None)
    return float(np.hypot(coef[0], coef[1]))
def rms(y):
    return float(np.sqrt(np.mean(y[valid] ** 2)))
def gain_db(input_amp, output_amp):
    return float(20 * np.log10(max(output_amp, 1e-15) / input_amp))

results = {"fs_hz": FS, "duracion_s": DURATION, "semilla": SEED,
           "amplitudes_entrada": AMPS, "filtros": {}}
input_measured = {name: fit_amplitude(measurement, freq) for name, freq in FREQS.items()}
for name, y in outputs.items():
    amplitudes = {component: fit_amplitude(y, freq) for component, freq in FREQS.items()}
    results["filtros"][name] = {
        "rms_salida": rms(y),
        "amplitudes_salida": amplitudes,
        "ganancias_db": {component: gain_db(input_measured[component], amplitudes[component])
                         for component in FREQS},
    }
results["rms_entrada"] = rms(measurement)
results["amplitudes_entrada_medidas"] = input_measured

# Registro y densidad espectral de la lectura de entrada.
fig, axes = plt.subplots(2, 1, figsize=(10, 6.5), constrained_layout=True)
view = (t >= 0) & (t <= 8)
axes[0].plot(t[view], measurement[view], color="#684A73", lw=0.8, label="Medición con ruido")
axes[0].plot(t[view], clean[view], color="#D69A38", lw=1.1, alpha=.9, label="Componentes programadas")
axes[0].set(title="Lectura sintética de caudal", xlabel="Tiempo (s)", ylabel="Variación (L/s)")
axes[0].legend(frameon=False, ncol=2); axes[0].grid(alpha=.23)
f, pxx = signal.welch(measurement, fs=FS, nperseg=2048)
axes[1].plot(f, 10*np.log10(pxx+1e-15), color="#377F86", lw=1.0)
axes[1].set(xlim=(0, 25), title="Densidad espectral de la entrada", xlabel="Frecuencia (Hz)", ylabel="Potencia (dB/Hz)")
for label, hz in FREQS.items():
    axes[1].axvline(hz, color="#C75C4A", ls="--", lw=.8, alpha=.8, label=f"{hz:g} Hz")
axes[1].legend(frameon=False, ncol=3); axes[1].grid(alpha=.23)
fig.savefig(FIG/"entrada_caudal.png", dpi=180); plt.close(fig)

# Respuesta en frecuencia de cada diseño.
fig, ax = plt.subplots(figsize=(10, 5.2), constrained_layout=True)
for name, (kind, mode, coeff) in filters.items():
    if mode == "sos": freq, h = signal.sosfreqz(coeff, worN=4096, fs=FS)
    else: freq, h = signal.freqz(coeff[0], coeff[1], worN=4096, fs=FS)
    ax.plot(freq, 20*np.log10(np.maximum(np.abs(h),1e-6)), lw=1.3, label=name)
for hz in FREQS.values(): ax.axvline(hz, color="#7D8285", ls=":", lw=.8)
ax.set(xlim=(0,25), ylim=(-100,4), title="Respuesta de magnitud de los diseños", xlabel="Frecuencia (Hz)", ylabel="Magnitud (dB)")
ax.grid(alpha=.23); ax.legend(frameon=False)
fig.savefig(FIG/"respuesta_filtros.png", dpi=180); plt.close(fig)

# Las salidas se escalan verticalmente en paneles para comparar la forma sin solaparlas.
fig, axes = plt.subplots(4, 1, figsize=(10, 8.0), sharex=True, constrained_layout=True)
sel = (t >= 5.0) & (t <= 9.0)
series = [("Entrada", measurement, "#684A73"),
          ("Pasa bajos Butterworth", outputs["Pasa bajos Butterworth"], "#377F86"),
          ("Pasa altos Chebyshev II", outputs["Pasa altos Chebyshev II"], "#C75C4A"),
          ("Pasa bandas FIR Kaiser", outputs["Pasa bandas FIR Kaiser"], "#D69A38")]
for ax, (label, y, color) in zip(axes, series):
    ax.plot(t[sel], y[sel], color=color, lw=1.0, label=label)
    if label != "Entrada": ax.plot(t[sel], clean[sel], color="#30383D", lw=.65, ls="--", alpha=.55, label="Suma de referencia")
    ax.set_ylabel("L/s"); ax.grid(alpha=.2); ax.legend(frameon=False, loc="upper right")
axes[-1].set_xlabel("Tiempo (s)"); fig.suptitle("Comparación de salidas durante cuatro segundos")
fig.savefig(FIG/"comparacion_temporal.png", dpi=180); plt.close(fig)

# Espectros para observar qué componentes permanecen tras cada filtro.
fig, ax = plt.subplots(figsize=(10,5.2),constrained_layout=True)
for label,y,color in [("Entrada",measurement,"#A5A9AA"),
    ("Pasa bajos",outputs["Pasa bajos Butterworth"],"#377F86"),
    ("Pasa altos",outputs["Pasa altos Chebyshev II"],"#C75C4A"),
    ("Pasa bandas",outputs["Pasa bandas FIR Kaiser"],"#D69A38")]:
    f,p=signal.welch(y,fs=FS,nperseg=2048)
    ax.plot(f,10*np.log10(p+1e-15),color=color,lw=1.0,label=label)
ax.set(xlim=(0,25),title="Densidad espectral antes y después",xlabel="Frecuencia (Hz)",ylabel="Potencia (dB/Hz)")
ax.grid(alpha=.22); ax.legend(frameon=False,ncol=2)
fig.savefig(FIG/"espectros_filtros.png",dpi=180); plt.close(fig)

with (OUT/"ganancia_componentes.csv").open("w",newline="",encoding="utf-8") as f:
    writer=csv.writer(f); writer.writerow(["Filtro","Deriva 0.18 Hz (dB)","Pulsación 1.20 Hz (dB)","Interferencia 18 Hz (dB)","RMS salida (L/s)"])
    for name,data in results["filtros"].items():
        g=data["ganancias_db"]
        writer.writerow([name,f"{g['Deriva de proceso']:.2f}",f"{g['Pulsación de bomba']:.2f}",f"{g['Interferencia eléctrica']:.2f}",f"{data['rms_salida']:.4f}"])
(OUT/"resumen.json").write_text(json.dumps(results,indent=2,ensure_ascii=False),encoding="utf-8")
print(json.dumps(results,indent=2,ensure_ascii=False))
